import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.*;

import java.util.ArrayList;

public class Menu {
    private static ArrayList<Medicamento> medicamentos = new ArrayList<>();
    private String caminho = "";
    public Menu(String caminho){
        this.caminho = caminho;
        leCSV();
    }

    private void leCSV() {
      String line = "";
      String lineAux = "";
      try {
        BufferedReader br = new BufferedReader(new FileReader(caminho));
        br.readLine();
        while ((line = br.readLine()) != null)
        {
          if(line.length()< 260 && lineAux.length()<300){
            lineAux += line;
            continue;
          }
          if(!lineAux.equals("")){
            medicamentos.add(new Medicamento(toMap(lineAux)));
            lineAux = "";
            if(line.length()< 260){
              lineAux += line;
              continue;
            }
          }
          medicamentos.add(new Medicamento(toMap(line)));
        }
        br.close();
      }
      catch(IOException e) {
        e.printStackTrace();
      }
  }

  private static List<String> split(String str){ 
    return Stream.of(str.split("[;]"))
      .map (elem -> new String(elem))
      .collect(Collectors.toList());
  }

  private static List<String> toObjectList(List<String> list){
          boolean aspasAbertas =false;
          List<String> lista = new ArrayList<String>();
          List<String> listaFinal = new ArrayList<String>();
          for(String s: list){
            if(s.contains("\"")){
              if(s.charAt(0)=='"'&& s.charAt(s.length()-1)=='"'){
                listaFinal.add(s);
                continue;
              }
              s = s.replace("\"","");
              lista.add(s);
              if(aspasAbertas){
                aspasAbertas=false;
                listaFinal.add(String.join(";",lista));
                lista = new ArrayList<>();
                continue;
              }
              else aspasAbertas=true;
            }
            if(aspasAbertas){
              lista.add(s);
            }else
            listaFinal.add(s);
          }
          return listaFinal;
  }
  private static Map<Colunas,String> toMap(String str){
    List<String> list = toObjectList((split(str)));
    Map<Colunas, String> map = new HashMap<>();
    IntStream.range(0,list.size())
      .forEach(index -> map.put(Colunas.values()[index],list.get(index)));
    return map;
  }

  public static ArrayList<Medicamento> searchByName(String name){
    ArrayList<Medicamento> resultado = new ArrayList<>();

    for (Medicamento med : medicamentos) {
      //System.out.println(med.getEAN1());
      if(med.getComercializacao2020().equals("Não")){
        continue;
      }
      if(validaNome(name,med.getProduto())){
        resultado.add(med);
      }
    }
    return resultado;
  }

  private static boolean validaNome(String n1, String n2){
    for(int i = 0; i < n1.length(); i++){
      if(i>= n2.length())
        return false;
      if(n1.toUpperCase().charAt(i)==n2.toUpperCase().charAt(i)){
        continue;
      }else
        return false;
    }
    return true;
  }

  public static ArrayList<Medicamento> searchByEAN(String cod_barras){
    ArrayList<Medicamento> resultado = new ArrayList<>();
    if(cod_barras.equals(""))
      return resultado;
    for (Medicamento med : medicamentos) {
      if(validaNome(cod_barras,med.getEAN1())||
          validaNome(cod_barras,med.getEAN3())||
            validaNome(cod_barras,med.getEAN3())){
        resultado.add(med);
      }
    }
    return resultado;
  }

  public static Map<String,Double> comparativoPisCofins(){
    Map<String,Double> resultado = new HashMap<>();
    double positiva=0,negativa=0,neutra=0;
    for (Medicamento med : medicamentos) {
      switch(med.getPisCofins()){
        case "Positiva":
          positiva++;
          break;
        case "Neutra":
          neutra++;
          break;
        case "Negativa":
          negativa++;
          break;
        default:
          break;
      }
    }
    resultado.put("Positiva",Math.round(positiva*100/medicamentos.size()*100.0)/100.0);
    resultado.put("Neutra",Math.round(neutra*100/medicamentos.size()*100.0)/100.0);
    resultado.put("Negativa",Math.round(negativa*100/medicamentos.size()*100.0)/100.0);

    return resultado;
  }

  public static ArrayList<Medicamento> getMedicamentos(){
    return medicamentos;
  }
}



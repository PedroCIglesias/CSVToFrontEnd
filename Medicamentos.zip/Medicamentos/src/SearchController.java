

import java.io.File;
import java.io.IOException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class SearchController {

    @FXML
    private Button bt_pesquisa;

    @FXML
    private Button bt_csv;

    @FXML
    private Button bt_comparativo;

    @FXML
    private TableView<Medicamento> tb_registros;

    @FXML
    private Label lbl_nomeArquivo;

    @FXML
    private TableColumn<Medicamento,String> colunaSubstancia, colunaCNPJ, colunaLaboratorio, colunaCodigoGgrem, colunaRegistro, colunaEAN1,
    colunaEAN2, colunaEAN3, colunaProduto, colunaApresentacao, colunaClasseTerapeutica, colunaTipoDeProduto, colunaRegimeDePreco, colunaPFSemImposto, colunaPF0,
    colunaPF12, colunaPF17, colunaPF17ALC, colunaPF17h, colunaPF17hALC, colunaPF18, colunaPF18ALC, colunaPF20, colunaPMC0, colunaPMC12, colunaPMC17, colunaPMC17ALC, colunaPMC17h, colunaPMC17hALC,
    colunaPMC18, colunaPMC18ALC, colunaRestricao, colunaCap, colunaConfaz, colunaICMS, colunaAnaliseRecursal, colunaListaConcessao, colunaComercializacao2020, colunaTarja;;

    @FXML
    private TextField txt_pesquisa;

    final FileChooser fc = new FileChooser();

    @FXML
    void pesquisa(ActionEvent event) {
        buscaRegistros();
    }

    @FXML
    void comparativo(ActionEvent event) throws IOException {
        Parent parent = FXMLLoader.load(getClass().getResource("Grafico.fxml"));
        Scene scene_grafico = new Scene(parent);
        Stage app_stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
        
        app_stage.hide();
        app_stage.setScene(scene_grafico);
        app_stage.setTitle("Gráfico PIS/COFINS");
        app_stage.show();
    }

    @FXML
    private void initialize(){
        colunaProduto = new TableColumn<Medicamento,String>("Produto");
        colunaProduto.setCellValueFactory(cellData -> cellData.getValue().getProdutoProperty());
        colunaProduto.setVisible(false);

        colunaApresentacao = new TableColumn<Medicamento,String>("Apresentação");
        colunaApresentacao.setCellValueFactory(cellData -> cellData.getValue().getApresentacaoProperty());
        colunaApresentacao.setVisible(false);
        
        colunaPFSemImposto = new TableColumn<Medicamento,String>("PF Sem Impostos");
        colunaPFSemImposto.setCellValueFactory(cellData -> cellData.getValue().getPfSemImpostoProperty());
        colunaPFSemImposto.setVisible(false);

        colunaEAN1 = new TableColumn<Medicamento,String>("EAN1");
        colunaEAN1.setCellValueFactory(cellData -> cellData.getValue().getEAN1Property());
        colunaEAN1.setVisible(false);

        colunaEAN2 = new TableColumn<Medicamento,String>("EAN2");
        colunaEAN2.setCellValueFactory(cellData -> cellData.getValue().getEAN2Property());
        colunaEAN2.setVisible(false);

        colunaEAN3 = new TableColumn<Medicamento,String>("EAN3");
        colunaEAN3.setCellValueFactory(cellData -> cellData.getValue().getEAN3Property());
        colunaEAN3.setVisible(false);

        colunaProduto = new TableColumn<Medicamento,String>("Produto");
        colunaProduto.setCellValueFactory(cellData -> cellData.getValue().getProdutoProperty());
        colunaProduto.setVisible(false);

        colunaSubstancia = new TableColumn<Medicamento,String>("Substancia");
        colunaSubstancia.setCellValueFactory(cellData -> cellData.getValue().getSubstancia());
        colunaSubstancia.setVisible(false);

        colunaCNPJ = new TableColumn<Medicamento,String>("CNPJ");
        colunaCNPJ.setCellValueFactory(cellData -> cellData.getValue().getCNPJ());
        colunaCNPJ.setVisible(false);

        colunaLaboratorio = new TableColumn<Medicamento,String>("Laboratorio");
        colunaLaboratorio.setCellValueFactory(cellData -> cellData.getValue().getLaboraratorio());
        colunaLaboratorio.setVisible(false);

        colunaCodigoGgrem = new TableColumn<Medicamento,String>("Código Ggrem");
        colunaCodigoGgrem.setCellValueFactory(cellData -> cellData.getValue().getCodGGRem());
        colunaCodigoGgrem.setVisible(false);

        colunaRegistro = new TableColumn<Medicamento,String>("Registro");
        colunaRegistro.setCellValueFactory(cellData -> cellData.getValue().getRegistro());
        colunaRegistro.setVisible(false);

        colunaListaConcessao = new TableColumn<Medicamento,String>("Lista Concessão");
        colunaListaConcessao.setCellValueFactory(cellData -> cellData.getValue().getListaConcessao());
        colunaListaConcessao.setVisible(false);

        colunaComercializacao2020 = new TableColumn<Medicamento,String>("Comercialização 2020");
        colunaComercializacao2020.setCellValueFactory(cellData -> cellData.getValue().getComercio2020());
        colunaComercializacao2020.setVisible(false);

        colunaTarja = new TableColumn<Medicamento,String>("Tarja");
        colunaTarja.setCellValueFactory(cellData -> cellData.getValue().getTarja());
        colunaTarja.setVisible(false);


        tb_registros.getColumns().add(colunaProduto);
        tb_registros.getColumns().add(colunaApresentacao);
        tb_registros.getColumns().add(colunaPFSemImposto);
        tb_registros.getColumns().add(colunaEAN1);
        tb_registros.getColumns().add(colunaEAN2);
        tb_registros.getColumns().add(colunaEAN3);
        tb_registros.getColumns().add(colunaSubstancia);
        tb_registros.getColumns().add(colunaCNPJ);
        tb_registros.getColumns().add(colunaLaboratorio);
        tb_registros.getColumns().add(colunaCodigoGgrem);
        tb_registros.getColumns().add(colunaRegistro);
        tb_registros.getColumns().add(colunaListaConcessao);
        tb_registros.getColumns().add(colunaComercializacao2020);
        tb_registros.getColumns().add(colunaTarja);
    }

    @FXML
    private void digita(KeyEvent keyEvent){
        if(keyEvent.getCode().equals(KeyCode.ENTER)){
            pesquisa(new ActionEvent());
            bt_pesquisa.requestFocus();
        }else
            buscaRegistros();
    }

    private void buscaRegistros(){
        String texto = txt_pesquisa.getText();
        setVisibleAllColumns(false);
        if(texto.equals("")){
            return;
        }
        if(texto.matches("[0-9]*")){
            ObservableList<Medicamento> listObserval = FXCollections.observableArrayList(Menu.searchByEAN(txt_pesquisa.getText()));
            
            colunaProduto.setVisible(true);
            colunaApresentacao.setVisible(true);
            colunaPFSemImposto.setVisible(true);
            colunaEAN1.setVisible(true);
            colunaEAN2.setVisible(true);
            colunaEAN3.setVisible(true);
            
            tb_registros.setItems(listObserval);
        }else{
            ObservableList<Medicamento> listObserval = FXCollections.observableArrayList(Menu.searchByName(txt_pesquisa.getText()));

            colunaProduto.setVisible(true);
            colunaApresentacao.setVisible(true);
            colunaPFSemImposto.setVisible(true);

            tb_registros.setItems(listObserval);
        }
    }

    @FXML
        private void abrirCSV(ActionEvent event) {
        fc.setTitle("Selecione o arquivo CSV");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Arquivos CSV", "*.csv"));
        File file = fc.showOpenDialog(null);
        
        if(file != null){
            Task task = new Task(){
                @Override
                protected Integer call() throws Exception{
                    Scene scene = bt_csv.getScene();
                    scene.setCursor(Cursor.WAIT);
                    Menu menu = new Menu(file.getAbsolutePath());
                    mostraTodosDados();
                    scene.setCursor(Cursor.DEFAULT);
                    return 0;
                }
            };
            Thread th = new Thread(task);
            th.setDaemon(true);
            th.start();
            lbl_nomeArquivo.setText(file.getName());
        }
        
    }

    private void mostraTodosDados(){
        ObservableList<Medicamento> listObserval = FXCollections.observableArrayList(Menu.getMedicamentos());
        setVisibleAllColumns(true);
        tb_registros.setItems(listObserval);
    }


    private void setVisibleAllColumns(boolean arg){
        colunaProduto.setVisible(arg);
        colunaApresentacao.setVisible(arg);
        colunaPFSemImposto.setVisible(arg);
        colunaEAN1.setVisible(arg);
        colunaEAN2.setVisible(arg);
        colunaEAN3.setVisible(arg);
        colunaSubstancia.setVisible(arg);
        colunaCNPJ.setVisible(arg);
        colunaLaboratorio.setVisible(arg);
        colunaCodigoGgrem.setVisible(arg);
        colunaRegistro.setVisible(arg);
        colunaListaConcessao.setVisible(arg);
        colunaComercializacao2020.setVisible(arg);
        colunaTarja.setVisible(arg);
    }
}

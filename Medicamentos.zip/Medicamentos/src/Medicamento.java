import java.util.Map;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class Medicamento {
    /*private String substancia, cnpj, laboratorio, codigoGgrem, registro, EAN1,
            EAN2, EAN3, produto, apresentacao, classeTerapeutica, tipoDeProduto, regimeDePreco, pfSemImposto, pf0,
            pf12, pf17, pf17ALC, pf17h, pf17hALC, pf18, pf18ALC, pf20, pmc0, pmc12, pmc17, pmc17ALC, pmc17h, pmc17hALC,
            pmc18, pmc18ALC, restricao, cap, confaz, icms, analiseRecursal, listaConcessao, comercializacao2020, tarja;*/

    private StringProperty substancia, cnpj, laboratorio, codigoGGrem, registro, ean1, ean2, ean3, produto, apresentacao,
                                 pfSemImposto, listaConcessao, comercializacao2020, tarja;

    private Map<Colunas, String> colunas;

    public Medicamento(Map<Colunas,String> colunas) {
        this.colunas = colunas;
        alimentaDados();
    }
    private void alimentaDados(){
        substancia = new SimpleStringProperty(colunas.get(Colunas.SUBSTANCIA).toString());
        cnpj = new SimpleStringProperty(colunas.get(Colunas.CNPJ).toString());
        laboratorio = new SimpleStringProperty(colunas.get(Colunas.LABORATORIO).toString());
        codigoGGrem = new SimpleStringProperty(colunas.get(Colunas.COD_GGREM).toString());
        registro = new SimpleStringProperty(colunas.get(Colunas.REGISTRO).toString());
        ean1 = new SimpleStringProperty(colunas.get(Colunas.EAN1).toString());
        ean2 = new SimpleStringProperty(colunas.get(Colunas.EAN2).toString());
        ean3 = new SimpleStringProperty(colunas.get(Colunas.EAN3).toString());
        produto = new SimpleStringProperty(colunas.get(Colunas.PRODUTO).toString());
        apresentacao = new SimpleStringProperty(colunas.get(Colunas.APRESENTACAO).toString());
        pfSemImposto = new SimpleStringProperty(colunas.get(Colunas.PF_S_IMPOSTO).toString());
        listaConcessao = new SimpleStringProperty(colunas.get(Colunas.PIS_COFINS).toString());
        comercializacao2020 = new SimpleStringProperty(colunas.get(Colunas.COMERCIO_2020).toString());
        tarja = new SimpleStringProperty(colunas.get(Colunas.TARJA).toString());
    }

    public StringProperty getProdutoProperty(){
        return produto;
    }
    public StringProperty getApresentacaoProperty(){
        return apresentacao;
    }
    public StringProperty getPfSemImpostoProperty(){
        return pfSemImposto;
    }
    public StringProperty getEAN1Property(){
        return ean1;
    }
    public StringProperty getEAN2Property(){
        return ean2;
    }
    public StringProperty getEAN3Property(){
        return ean3;
    }
    public StringProperty getSubstancia(){
        return substancia;
    }
    public StringProperty getCNPJ(){
        return cnpj;
    }
    public StringProperty getLaboraratorio(){
        return laboratorio;
    }
    public StringProperty getCodGGRem(){
        return codigoGGrem;
    }
    public StringProperty getRegistro(){
        return registro;
    }
    public StringProperty getListaConcessao(){
        return listaConcessao;
    }
    public StringProperty getComercio2020(){
        return comercializacao2020;
    }
    public StringProperty getTarja(){
        return tarja;
    }


    public String getProduto() {
       return colunas.get(Colunas.PRODUTO).toString();
    }
    public String getApresentacao() {
        return colunas.get(Colunas.APRESENTACAO).toString();
    }

    public String getPfSemImposto() {
        return colunas.get(Colunas.PF_S_IMPOSTO).toString();
    }

    public String getComercializacao2020(){
        return colunas.get(Colunas.COMERCIO_2020).toString();
    }

    public String getEAN1(){
        return colunas.get(Colunas.EAN1).toString();
    }

    public String getEAN2(){
        return colunas.get(Colunas.EAN2).toString();
    }

    public String getEAN3(){
        return colunas.get(Colunas.EAN3).toString();
    }

    public String getPisCofins(){
        return colunas.get(Colunas.PIS_COFINS).toString();
    }

}

import java.io.IOException;
import java.util.Map;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.Node;

public class GraphController {

    @FXML
    private Button bt_voltar;

    @FXML
    private PieChart gr_pisCofins;

    @FXML
    public void initialize(){
        Map<String,Double> comparativo = Menu.comparativoPisCofins();
        ObservableList<PieChart.Data> pieChartData =
            FXCollections.observableArrayList(
                new PieChart.Data("Positiva"+"("+ comparativo.get("Positiva") +"%)",comparativo.get("Positiva")),
                new PieChart.Data("Neutra"+"("+ comparativo.get("Neutra") +"%)",comparativo.get("Neutra")),
                new PieChart.Data("Negativa"+"("+ comparativo.get("Negativa") +"%)",comparativo.get("Negativa")));
        gr_pisCofins.setData(pieChartData);
        gr_pisCofins.setTitle("Compartativo PIS/COFINS");
    }
    @FXML
    void voltar(ActionEvent event) throws IOException {
        Parent parent = FXMLLoader.load(getClass().getResource("MedicamentosLayout.fxml"));
        Scene scene_medicamentoLayout = new Scene(parent);
        Stage app_stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
        
        app_stage.hide();
        app_stage.setScene(scene_medicamentoLayout);
        app_stage.setTitle("Tabela Medicamentos");
        app_stage.show();
    }

}
